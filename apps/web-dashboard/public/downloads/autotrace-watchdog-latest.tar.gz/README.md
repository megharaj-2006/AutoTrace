# AutoTrace-Sec Telemetry Watchdog (1.2.0)

Lightweight (< 15 MB) zero-dependency host daemon for B2B production deployment.

## Quick Start
1. Edit configuration:
   nano conf/watchdog.conf
2. Run installation:
   sudo ./install.sh --token=<YOUR_TOKEN> --gateway=http://localhost:8085
3. Or execute directly:
   ./autotrace-watchdog start --token=<YOUR_TOKEN>
