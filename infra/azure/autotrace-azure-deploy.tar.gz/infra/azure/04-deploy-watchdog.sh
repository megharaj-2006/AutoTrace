#!/usr/bin/env bash
# ==============================================================================
# AutoTrace-Sec Azure VM Provisioning: Step 6 (Compile & Attach eBPF Watchdog)
# ==============================================================================
set -euo pipefail

WATCHDOG_DIR="$HOME/autotrace-watchdog"
mkdir -p "$WATCHDOG_DIR"
cp -r services/telemetry-watchdog/* "$WATCHDOG_DIR/"
cd "$WATCHDOG_DIR"

echo "Compiling native C entropy engine..."
gcc -O2 src/watchdog.c -o bin/autotrace-watchdog-native -lm
chmod +x bin/autotrace-watchdog-native
bin/autotrace-watchdog-native --version

echo "Verifying kernel BPF capabilities..."
sudo bpftool feature probe || true

echo "Configuring permissions (CAP_BPF / CAP_NET_ADMIN / CAP_SYS_ADMIN)..."
sudo setcap cap_bpf,cap_net_admin,cap_sys_admin+ep bin/autotrace-watchdog-native 2>/dev/null || true

echo "Starting Telemetry Watchdog Host Daemon (< 15 MB footprint)..."
chmod +x autotrace-watchdog

# Stop any running watchdog
pkill -f autotrace-watchdog || true

# Run watchdog in daemon mode pointing to local Express backend & Redpanda
nohup python3 autotrace-watchdog \
    --gateway http://localhost:8080 \
    --port 8088 \
    --token az_prod_azureuser \
    --mode interceptor \
    > "$WATCHDOG_DIR/watchdog.log" 2>&1 &

sleep 2
echo "Watchdog process status:"
ps aux | grep "[a]utotrace-watchdog" || true

echo "Emitting test synthetic traffic to trigger socket capture..."
curl -s -X POST http://localhost:8080/api/v1/telemetry/record \
    -H "Content-Type: application/json" \
    -d '{
      "trace_id": "test-bpf-socket-001",
      "source_service": "gateway-service",
      "target_service": "order-service",
      "endpoint": "/orders/checkout",
      "method": "POST",
      "status_code": 200,
      "latency_ms": 14.2,
      "payload_entropy": 4.1205,
      "timestamp": '$(date +%s%N | cut -b1-13)'
    }'

echo ""
echo "Verifying Express graph topology ingestion..."
curl -s http://localhost:8080/api/graph | jq . || curl -s http://localhost:8080/api/graph

echo "eBPF Watchdog attached and emitting telemetry."
